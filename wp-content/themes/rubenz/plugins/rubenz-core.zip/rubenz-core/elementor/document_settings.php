<?php

/**
 * Add new controls after end of "General Settings"
 */
add_action( 'elementor/element/wp-page/document_settings/after_section_end', 'arts_add_elementor_document_settings_after_controls' );
add_action( 'elementor/element/wp-post/document_settings/after_section_end', 'arts_add_elementor_document_settings_after_controls' );

function arts_add_elementor_document_settings_after_controls( \Elementor\Core\DocumentTypes\PageBase $page ) {

	$post_id           = get_the_ID();
	$post_type         = get_post_type( $post_id );
	$is_portfolio_item = $post_type == 'arts_portfolio_item';

	$page->start_controls_section(
		'page_masthead_section',
		[
			'label' => esc_html__( 'Page Masthead', 'rubenz' ),
			'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS,
		]
	);

	/**
	 * Page Masthead Layout
	 */
	$page->add_control(
		'page_masthead_layout',
		[
			'label'   => esc_html__( 'Layout', 'rubenz' ),
			'type'    => \Elementor\Controls_Manager::SELECT,
			'options' => [
				'content_top'              => esc_html__( 'Content Top & Image Bottom', 'rubenz' ),
				'halfscreen_content_left'  => esc_html__( 'Halfscreen: Content Left & Image Right', 'rubenz' ),
				'halfscreen_content_right' => esc_html__( 'Halfscreen: Content Right & Image Left', 'rubenz' ),
				'fullscreen'               => esc_html__( 'Fullscreen', 'rubenz' ),
			],
			'default' => 'content_top',
		]
	);

	$page->add_control(
		'page_masthead_alignment',
		[
			'label'   => esc_html__( 'Content Alignment', 'rubenz' ),
			'type'    => \Elementor\Controls_Manager::CHOOSE,
			'options' => [
				'text-left'   => [
					'title' => esc_html__( 'Left', 'rubenz' ),
					'icon'  => 'fa fa-fw fa-align-left',
				],
				'text-center' => [
					'title' => esc_html__( 'Center', 'rubenz' ),
					'icon'  => 'fa fa-fw fa-align-center',
				],
				'text-right'  => [
					'title' => esc_html__( 'Right', 'rubenz' ),
					'icon'  => 'fa fa-fw fa-align-right',
				],
			],
			'default' => 'text-left',
			'toggle'  => false,
		]
	);

	$page->add_control(
		'heading_image',
		[
			'label'     => esc_html__( 'Background Image', 'rubenz' ),
			'type'      => \Elementor\Controls_Manager::HEADING,
			'separator' => 'before',
		]
	);

	/**
	 * Page Masthead Overlay Opacity
	 */
	$page->add_control(
		'page_masthead_overlay_opacity',
		[
			'label'     => esc_html__( 'Image Overlay Opacity', 'rubenz' ),
			'type'      => \Elementor\Controls_Manager::SLIDER,
			'default'   => [
				'size' => .6,
			],
			'range'     => [
				'px' => [
					'max'  => 1,
					'step' => 0.01,
				],
			],
			'selectors' => [
				'{{WRAPPER}} .section-masthead__overlay' => 'opacity: {{SIZE}};',
			],
			'condition' => [
				'page_masthead_layout' => 'fullscreen',
			],
		]
	);

	/**
	 * Min Height
	 */
	$page->add_responsive_control(
		'page_masthead_image_height',
		[
			'label'           => esc_html__( 'Image Height', 'rubenz' ),
			'type'            => \Elementor\Controls_Manager::SLIDER,
			'desktop_default' => [
				'size' => 900,
				'unit' => 'px',
			],
			'tablet_default'  => [
				'size' => 70,
				'unit' => 'vh',
			],
			'mobile_default'  => [
				'size' => 50,
				'unit' => 'vh',
			],
			'range'           => [
				'px' => [
					'min' => 0,
					'max' => 1440,
				],
				'vh' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'size_units'      => [ 'px', 'vh' ],
			'selectors'       => [
				'{{WRAPPER}} .section-masthead__background' => 'height: 1px; min-height: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .section-masthead__background:after' => 'content: ""; min-height: inherit;', // Hack for IE11
			],
			'condition'       => [
				'post_featured_image!' => array(
					'id'  => '',
					'url' => '',
				),
				'page_masthead_layout' => 'content_top',
			],
		]
	);

	$page->add_control(
		'page_masthead_image_layout',
		[
			'label'     => esc_html__( 'Image Alignment', 'rubenz' ),
			'type'      => \Elementor\Controls_Manager::CHOOSE,
			'options'   => [
				'section'                   => [
					'title' => esc_html__( 'Fullwidth', 'rubenz' ),
					'icon'  => 'fa fa-fw fa-arrows-h',
				],
				'section_w-container-left'  => [
					'title' => esc_html__( 'Left', 'rubenz' ),
					'icon'  => 'fa fa-fw fa-align-left',
				],
				'container'                 => [
					'title' => esc_html__( 'Center', 'rubenz' ),
					'icon'  => 'fa fa-fw fa-align-center',
				],
				'section_w-container-right' => [
					'title' => esc_html__( 'Right', 'rubenz' ),
					'icon'  => 'fa fa-fw fa-align-right',
				],
			],
			'default'   => 'section',
			'condition' => array(
				'page_masthead_layout' => 'content_top',
			),
			'toggle'    => false,
		]
	);

	/**
	 * Image Parallax
	 */
	$page->add_control(
		'page_masthead_image_parallax',
		[
			'label'     => esc_html__( 'Enable Parallax', 'Elementor Widget', 'rubenz' ),
			'type'      => \Elementor\Controls_Manager::SWITCHER,
			'default'   => 'yes',
			'condition' => [
				'post_featured_image!' => array(
					'id'  => '',
					'url' => '',
				),
			],
		]
	);

	/**
	 * Image Parallax Speed
	 */
	$page->add_control(
		'page_masthead_image_parallax_speed',
		[
			'label'     => esc_html__( 'Parallax Speed', 'Elementor Widget', 'rubenz' ),
			'type'      => \Elementor\Controls_Manager::SLIDER,
			'range'     => [
				'factor' => [
					'min'  => -0.5,
					'max'  => 0.5,
					'step' => 0.01,
				],
			],
			'default'   => [
				'unit' => 'factor',
				'size' => 0.1,
			],
			'condition' => [
				'page_masthead_image_parallax' => 'yes',
				'post_featured_image!'         => array(
					'id'  => '',
					'url' => '',
				),
			],
		]
	);

	$page->end_controls_section();

	$page->start_controls_section(
		'footer_section',
		[
			'label' => esc_html__( 'Page Footer', 'rubenz' ),
			'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS,
		]
	);

	/**
	 * Override Footer
	 */
	$page->add_control(
		'page_footer_settings',
		[
			'label'       => esc_html__( 'Override Page Footer Settings', 'Elementor Widget Section', 'rubenz' ),
			'description' => esc_html__( 'Use custom footer settings for this page instead of global customizer settings', 'Elementor Widget Section', 'rubenz' ),
			'type'        => \Elementor\Controls_Manager::SWITCHER,
			'default'     => $is_portfolio_item ? 'yes' : '',
		]
	);

	/**
	 * Footer Hide
	 */
	$page->add_control(
		'page_footer_hide',
		[
			'label'     => esc_html__( 'Remove Footer from this Page', 'Elementor Widget Section', 'rubenz' ),
			'type'      => \Elementor\Controls_Manager::SWITCHER,
			'default'   => $is_portfolio_item ? 'yes' : '',
			'condition' => [
				'page_footer_settings' => 'yes',
			],
		]
	);

	$page->end_controls_section();

}

/**
 * Add new controls in the end of "General Settings"
 */
add_action( 'elementor/element/wp-page/document_settings/before_section_end', 'arts_add_elementor_document_settings_before_end_controls' );
add_action( 'elementor/element/wp-post/document_settings/before_section_end', 'arts_add_elementor_document_settings_before_end_controls' );

function arts_add_elementor_document_settings_before_end_controls( \Elementor\Core\DocumentTypes\PageBase $page ) {

	/**
	 * Page Color Theme
	 */
	$page->add_control(
		'page_main_color_theme',
		[
			'label'   => esc_html__( 'Page Color Theme', 'rubenz' ),
			'type'    => \Elementor\Controls_Manager::SELECT,
			'options' => [
				'bg-white'          => esc_html__( 'Pure White', 'rubenz' ),
				'bg-light-grey'     => esc_html__( 'Light 1', 'rubenz' ),
				'bg-light'          => esc_html__( 'Light 2', 'rubenz' ),
				'bg-blue-grey'      => esc_html__( 'Blue Grey 1', 'rubenz' ),
				'bg-blue-grey-dark' => esc_html__( 'Blue Grey 2', 'rubenz' ),
				'bg-dark'           => esc_html__( 'Dark 1', 'rubenz' ),
				'bg-dark-2'         => esc_html__( 'Dark 2', 'rubenz' ),
				'bg-black'          => esc_html__( 'Dark 3', 'rubenz' ),
			],
			'default' => 'bg-blue-grey',
		]
	);

}
