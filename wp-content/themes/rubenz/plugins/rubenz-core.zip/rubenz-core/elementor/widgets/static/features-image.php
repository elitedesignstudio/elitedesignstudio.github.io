<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Features_Image extends Widget_Base {

	public function get_name() {
		return 'rubenz-widget-features-image';
	}

	public function get_title() {
		return esc_html__( 'Features Image', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-plug';
	}

	public function get_categories() {
		return [ 'rubenz-static' ];
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {

		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = [
			'conditions'        => [ 'widgetType' => $name ],
			'fields'            => [
				[
					'field'       => 'counter',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Counter', 'rubenz' ) ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'heading',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Heading', 'rubenz' ) ),
					'editor_type' => 'LINE',
				],
			],
			'integration-class' => 'WPML_Rubenz_Elementor_Features_Image',
		];

		return $widgets;

	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', [ $this, 'wpml_widgets_to_translate_filter' ] );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'image_section',
			[
				'label' => esc_html__( 'Image', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'image',
			[
				'label'   => esc_html__( 'Choose Image', 'rubenz' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'image_background_color_theme',
			[
				'label'   => esc_html__( 'Image Background', 'rubenz' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'bg-white'              => esc_html__( 'Pure White', 'rubenz' ),
					'bg-light-grey'         => esc_html__( 'Light 1', 'rubenz' ),
					'bg-light'              => esc_html__( 'Light 2', 'rubenz' ),
					'bg-blue-grey'          => esc_html__( 'Blue Grey 1', 'rubenz' ),
					'bg-blue-grey-dark'     => esc_html__( 'Blue Grey 2', 'rubenz' ),
					'bg-dark color-white'   => esc_html__( 'Dark 1', 'rubenz' ),
					'bg-dark-2 color-white' => esc_html__( 'Dark 2', 'rubenz' ),
					'bg-black color-white'  => esc_html__( 'Dark 3', 'rubenz' ),
				],
				'default' => 'bg-dark-2 color-white',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'counter',
			[
				'label'   => esc_html__( 'Counter', 'rubenz' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '001',
			]
		);

		$this->add_control(
			'heading',
			[
				'label'   => esc_html__( 'Heading', 'rubenz' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Heading...', 'rubenz' ),
			]
		);

		$this->add_control(
			'show_decoration_line',
			[
				'label' => esc_html__( 'Show Line Decoration', 'rubenz' ),
				'type'  => Controls_Manager::SWITCHER,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'feature',
			[
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => esc_html__( 'Feature...', 'rubenz' ),
			]
		);

		$this->add_control(
			'features',
			[
				'type'          => Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'title_field'   => '{{{ feature }}}',
				'prevent_empty' => false,
			]
		);

		$this->add_control(
			'content_background_color_theme',
			[
				'label'   => esc_html__( 'Content Background', 'rubenz' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'bg-white'              => esc_html__( 'Pure White', 'rubenz' ),
					'bg-light-grey'         => esc_html__( 'Light 1', 'rubenz' ),
					'bg-light'              => esc_html__( 'Light 2', 'rubenz' ),
					'bg-blue-grey'          => esc_html__( 'Blue Grey 1', 'rubenz' ),
					'bg-blue-grey-dark'     => esc_html__( 'Blue Grey 2', 'rubenz' ),
					'bg-dark color-white'   => esc_html__( 'Dark 1', 'rubenz' ),
					'bg-dark-2 color-white' => esc_html__( 'Dark 2', 'rubenz' ),
					'bg-black color-white'  => esc_html__( 'Dark 3', 'rubenz' ),
				],
				'default' => 'bg-dark color-white',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'layout_section',
			[
				'label' => esc_html__( 'Layout', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_LAYOUT,
			]
		);

		$this->add_control(
			'composition_layout',
			[
				'label'   => esc_html__( 'Layout', 'rubenz' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'flex-lg-row'         => esc_html__( 'Content Left & Image Right', 'rubenz' ),
					'flex-lg-row-reverse' => esc_html__( 'Content Right & Image Left', 'rubenz' ),
				],
				'default' => 'flex-lg-row',
			]
		);

		$this->end_controls_section();

		/**
		 * Section Animation
		 */
		$this->start_controls_section(
			'animation_section',
			[
				'label' => esc_html__( 'Animation', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		/**
		 * OS Animation
		 */
		$this->add_control(
			'enable_animation',
			[
				'label'   => esc_html__( 'Enable on-scroll animation', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'section', 'class', [ 'section', 'section-composition', $settings['composition_layout'], $settings['content_background_color_theme'] ] );
		$this->add_render_attribute( 'image', 'class', [ 'section-composition__image', $settings['image_background_color_theme'] ] );
		$this->add_render_attribute( 'content', 'class', [ 'section-composition__content', $settings['content_background_color_theme'] ] );
		$this->add_render_attribute( 'property', 'class', 'figure-property' );
		$this->add_render_attribute( 'heading', 'class', 'split-text' );

		$this->add_inline_editing_attributes( 'counter' );
		$this->add_inline_editing_attributes( 'heading' );

		if ( $settings['enable_animation'] ) {
			$this->add_render_attribute( 'content', 'data-os-animation' );
		}

		if ( ! empty( $settings['image']['url'] ) ) {

			$img = wp_get_attachment_image_src( $settings['image']['id'], 'full' );

			$this->add_render_attribute(
				'wrapper', array(
					'class' => 'lazy',
					'style' => 'padding-bottom: calc( (' . $img[2] . '/' . $img[1] . ') * 100% ); height: 0;',
				)
			);

			$this->add_render_attribute(
				'img', array(
					'class'    => '',
					'data-src' => $settings['image']['url'],
					'src'      => '#',
					'alt'      => '',
				), true, true
			);

		}

		?>

		<div <?php echo $this->get_render_attribute_string( 'section' ); ?>>
			<div <?php echo $this->get_render_attribute_string( 'image' ); ?>>
				<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
					<img <?php echo $this->get_render_attribute_string( 'img' ); ?>>
				</div>
			</div>
			<div <?php echo $this->get_render_attribute_string( 'content' ); ?>>
				<?php if ( ! empty( $settings['counter'] ) ) : ?>
					<div class="section-composition__counter">
						<span <?php echo $this->get_render_attribute_string( 'counter' ); ?>><?php echo $settings['counter']; ?></span>
					</div>
				<?php endif; ?>
				<div <?php echo $this->get_render_attribute_string( 'property' ); ?>>
					<div class="figure-property__wrapper-heading figure-property__wrapper-heading_bold">
						<?php if ( $settings['show_decoration_line'] ) : ?>
							<div class="figure-property__headline"></div>
						<?php endif; ?>
						<?php if ( ! empty( $settings['heading'] ) ) : ?>
							<h6 <?php echo $this->get_render_attribute_string( 'heading' ); ?>><?php echo $settings['heading']; ?></h6>
						<?php endif; ?>
					</div>
					<?php if ( ! empty( $settings['features'] ) ) : ?>
						<div class="figure-property__content">
							<ul class="figure-property__list">
								<?php foreach ( $settings['features'] as $index => $item ) : ?>
									<?php
										$rowKey = $this->get_repeater_setting_key( 'feature', 'features', $index );
										$this->add_inline_editing_attributes( $rowKey );
									?>
									<li class="figure-property__item split-text">
										<div <?php echo $this->get_render_attribute_string( $rowKey ); ?>><?php echo $item['feature']; ?></div>
									</li>
								<?php endforeach; ?>
							</ul>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>

		<?php
	}

	protected function _content_template() {

		?>

		<#
			view.addRenderAttribute( 'section', 'class', [ 'section', 'section-composition', settings.composition_layout, settings.content_background_color_theme ] );
			view.addRenderAttribute( 'image', 'class', [ 'section-composition__image', settings.image_background_color_theme ] );
			view.addRenderAttribute( 'content', 'class', [ 'section-composition__content', settings.content_background_color_theme ] );
			view.addRenderAttribute( 'property', 'class', 'figure-property' );
			view.addRenderAttribute( 'heading', 'class', 'split-text' );

			view.addInlineEditingAttributes( 'counter' );
			view.addInlineEditingAttributes( 'heading' );

			if ( settings.image.url ) {

				view.addRenderAttribute(
					'wrapper', {
						'class': 'lazy',
					}
				);

				view.addRenderAttribute(
					'img', {
						'class': '',
						'data-src': settings.image.url,
						'src': '#',
						'alt': '',
					}, true, true
				);

			}

		#>

		<div {{{ view.getRenderAttributeString( 'section' ) }}}>
			<div {{{ view.getRenderAttributeString( 'image' ) }}}>
				<div {{{ view.getRenderAttributeString( 'wrapper' ) }}}>
					<img {{{ view.getRenderAttributeString( 'img' ) }}}>
				</div>
			</div>
			<div {{{ view.getRenderAttributeString( 'content' ) }}}>
				<# if ( settings.counter ) { #>
					<div class="section-composition__counter">
						<span {{{ view.getRenderAttributeString( 'counter' ) }}}>{{{ settings.counter }}}</span>
					</div>
				<# } #>
				<div {{{ view.getRenderAttributeString( 'property' ) }}}>
					<div class="figure-property__wrapper-heading figure-property__wrapper-heading_bold">
						<# if ( settings.show_decoration_line ) { #>
							<div class="figure-property__headline"></div>
						<# } #>
						<# if ( settings.heading ) { #>
							<h6 {{{ view.getRenderAttributeString( 'heading' ) }}}>{{{ settings.heading }}}</h6>
						<# } #>
					</div>
					<# if ( settings.features.length ) { #>
						<div class="figure-property__content">
							<ul class="figure-property__list">
								<# _.each( settings.features, function(item, index) { #>
									<#
										var rowKey = view.getRepeaterSettingKey( 'feature', 'features', index );
										view.addInlineEditingAttributes( rowKey );
									#>
									<li class="figure-property__item split-text">
										<div {{{ view.getRenderAttributeString( rowKey ) }}}>{{{ item.feature }}}</div>
									</li>
								<# }); #>
							</ul>
						</div>
					<# } #>
				</div>
			</div>
		</div>

		<?php
	}


}
