<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Features_List extends Widget_Base {

	public function get_name() {
		return 'rubenz-widget-features-list';
	}

	public function get_title() {
		return esc_html__( 'Features List', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-plug';
	}

	public function get_categories() {
		return [ 'rubenz-static' ];
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {

		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = [
			'conditions'        => [ 'widgetType' => $name ],
			'fields'            => [
				[
					'field'       => 'heading',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Heading', 'rubenz' ) ),
					'editor_type' => 'LINE',
				],
			],
			'integration-class' => 'WPML_Rubenz_Elementor_Features_List',
		];

		return $widgets;

	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', [ $this, 'wpml_widgets_to_translate_filter' ] );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'heading',
			[
				'label'   => esc_html__( 'Heading', 'rubenz' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Heading...', 'rubenz' ),
			]
		);

		$this->add_control(
			'show_decoration_line',
			[
				'label' => esc_html__( 'Show Line Decoration', 'rubenz' ),
				'type'  => Controls_Manager::SWITCHER,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'feature',
			[
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => esc_html__( 'Feature...', 'rubenz' ),
			]
		);

		$this->add_control(
			'features',
			[
				'type'          => Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'title_field'   => '{{{ feature }}}',
				'prevent_empty' => false,
			]
		);

		$this->end_controls_section();

		/**
		 * Section Animation
		 */
		$this->start_controls_section(
			'animation_section',
			[
				'label' => esc_html__( 'Animation', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		/**
		 * OS Animation
		 */
		$this->add_control(
			'enable_animation',
			[
				'label'   => esc_html__( 'Enable on-scroll animation', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'heading' );
		$this->add_render_attribute( 'section', 'class', 'figure-property' );
		$this->add_render_attribute( 'heading', 'class', 'split-text' );

		if ( $settings['enable_animation'] ) {
			$this->add_render_attribute( 'section', 'data-os-animation' );
		}

		?>

		<div <?php echo $this->get_render_attribute_string( 'section' ); ?>>
			<div class="figure-property__wrapper-heading figure-property__wrapper-heading_bold">
				<?php if ( $settings['show_decoration_line'] ) : ?>
					<div class="figure-property__headline"></div>
				<?php endif; ?>
				<?php if ( ! empty( $settings['heading'] ) ) : ?>
					<h6 <?php echo $this->get_render_attribute_string( 'heading' ); ?>><?php echo $settings['heading']; ?></h6>
				<?php endif; ?>
			</div>
			<?php if ( ! empty( $settings['features'] ) ) : ?>
				<div class="figure-property__content">
					<ul class="figure-property__list">
						<?php foreach ( $settings['features'] as $index => $item ) : ?>
							<?php
								$rowKey = $this->get_repeater_setting_key( 'feature', 'features', $index );
								$this->add_inline_editing_attributes( $rowKey );
							?>
							<li class="figure-property__item split-text">
								<div <?php echo $this->get_render_attribute_string( $rowKey ); ?>><?php echo $item['feature']; ?></div>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>
		</div>

		<?php
	}

	protected function _content_template() {

		?>

		<#

			view.addInlineEditingAttributes( 'heading' );
			view.addRenderAttribute( 'section', 'class', 'figure-property' );
			view.addRenderAttribute( 'heading', 'class', 'split-text' );

		#>

		<div {{{ view.getRenderAttributeString( 'section' ) }}}>
			<div class="figure-property__wrapper-heading figure-property__wrapper-heading_bold">
				<# if ( settings.show_decoration_line ) { #>
					<div class="figure-property__headline"></div>
				<# } #>
				<# if ( settings.heading ) { #>
					<h6 {{{ view.getRenderAttributeString( 'heading' ) }}}>{{{ settings.heading }}}</h6>
				<# } #>
			</div>
			<# if ( settings.features.length ) { #>
				<div class="figure-property__content">
					<ul class="figure-property__list">
						<# _.each( settings.features, function(item, index) { #>
							<#
								var rowKey = view.getRepeaterSettingKey( 'feature', 'features', index );
								view.addInlineEditingAttributes( rowKey );
							#>
							<li class="figure-property__item split-text">
								<div {{{ view.getRenderAttributeString( rowKey ) }}}>{{{ item.feature }}}</div>
							</li>
						<# }); #>
					</ul>
				</div>
			<# } #>
		</div>

		<?php
	}

}
