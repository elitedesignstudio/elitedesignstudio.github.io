<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Portfolio_Fullscreen_Headings_Slider extends Widget_Base {

	public function __construct( $data = [], $args = null ) {
		parent::__construct( $data, $args );
		$this->get_posts();
	}

	public function get_name() {
		return 'rubenz-widget-portfolio-fullscreen-headings-slider';
	}

	public function get_title() {
		return esc_html__( 'Portfolio Fullscreen Headings Slider', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-sitemap';
	}

	public function get_categories() {
		return [ 'rubenz-dynamic' ];
	}

	private $posts;
	private $post_type = '';

	private function get_posts() {

		$args = apply_filters(
			'arts/elementor/rubenz_widget_portfolio_fullscreen_headings_slider/query_args', array(
				'post_type'      => 'arts_portfolio_item',
				'posts_per_page' => -1,
			)
		);

		$posts   = array();
		$counter = 0;

		$loop = new \WP_Query( $args );

		if ( $loop->have_posts() ) {

			while ( $loop->have_posts() ) {

				$loop->the_post();

				$post_link  = get_the_permalink();
				$post_image = get_the_post_thumbnail_url();

				$posts[ $counter ]['id']          = get_the_ID();
				$posts[ $counter ]['title']       = get_the_title();
				$posts[ $counter ]['permalink']   = $post_link;
				$posts[ $counter ]['image']       = $post_image;
				$posts[ $counter ]['description'] = arts_get_field( 'text' );

				$counter++;

			}

			wp_reset_postdata();

		}

		$this->posts     = $posts;
		$this->post_type = array_key_exists( 'post_type', $args ) ? $args['post_type'] : '';

	}

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$posts     = $this->posts;
		$post_type = $this->post_type;

		foreach ( $posts as $index => $item ) {

			/**
			 * Heading Toggle
			 */
			$id = 'heading_toggle' . $item['id'];
			$this->add_control(
				$id,
				[
					'label'      => $item['title'],
					'type'       => Controls_Manager::HEADING,
					'conditions' => [
						'relation' => 'or',
						'terms'    => [
							[
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							],
							[
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							],
						],
					],
				]
			);

			/**
			 * Toggle
			 */
			$id = 'enabled' . $item['id'];
			$this->add_control(
				$id,
				[
					'label'      => esc_html__( 'Enabled', 'rubenz' ),
					'type'       => Controls_Manager::SWITCHER,
					'default'    => 'yes',
					'separator'  => 'after',
					'conditions' => [
						'relation' => 'or',
						'terms'    => [
							[
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							],
							[
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							],
						],
					],
				]
			);

		}

		$this->add_control(
			'dynamic_content_info',
			[
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => sprintf(
					'%1$s<br><br>%2$s <a href="%3$s" target="_blank">%4$s</a>',
					esc_html__( 'This widget displays content dynamically from the existing posts. It\'s not editable directly through Elementor Page Builder.', 'rubenz' ),
					esc_html__( 'You can edit your posts', 'rubenz' ),
					admin_url( 'edit.php?post_type=' . $post_type ),
					esc_html__( 'in WordPress admin panel', 'rubenz' )
				),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'settings_section',
			[
				'label' => esc_html__( 'Posts', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			]
		);

		$this->add_control(
			'posts_amount',
			[
				'label'   => esc_html__( 'Number of Posts to Display (0 for all)', 'rubenz' ),
				'type'    => Controls_Manager::SLIDER,
				'range'   => [
					'number' => [
						'min'  => 0,
						'max'  => 16,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'number',
					'size' => 5,
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'slider_section',
			[
				'label' => esc_html__( 'Slider', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			]
		);

		$this->add_control(
			'enable_autoplay',
			[
				'label'   => esc_html__( 'Autoplay', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'autoplay_delay',
			[
				'label'     => esc_html__( 'Autoplay Delay (ms)', 'rubenz' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'ms' => [
						'min'  => 1000,
						'max'  => 60000,
						'step' => 100,
					],
				],
				'default'   => [
					'unit' => 'ms',
					'size' => 6000,
				],
				'condition' => [
					'enable_autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'speed',
			[
				'label'   => esc_html__( 'Speed', 'rubenz' ),
				'type'    => Controls_Manager::SLIDER,
				'range'   => [
					'ms' => [
						'min'  => 100,
						'max'  => 10000,
						'step' => 100,
					],
				],
				'default' => [
					'unit' => 'ms',
					'size' => 1200,
				],
			]
		);

		$this->add_control(
			'enable_mousewheel_control',
			[
				'label'   => esc_html__( 'Enable Mousewheel Control', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'mousewheel_target',
			[
				'label'     => esc_html__( 'Mousewheel Events Target', 'rubenz' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '.page-wrapper',
				'options'   => [
					'.page-wrapper' => esc_html__( 'Page Wrapper', 'rubenz' ),
					'container'     => esc_html__( 'Container', 'rubenz' ),
				],
				'condition' => [
					'enable_mousewheel_control' => 'yes',
				],
			]
		);

		$this->add_control(
			'enable_keyboard_control',
			[
				'label'   => esc_html__( 'Enable Keyboard Control', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'enable_touch_control',
			[
				'label'   => esc_html__( 'Enable Touch Swipes Control', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'heading_controls',
			[
				'label'     => esc_html__( 'Controls', 'rubenz' ),
				'separator' => 'before',
				'type'      => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'enable_counter',
			[
				'label'   => esc_html__( 'Enable Counter', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'enable_arrows',
			[
				'label'   => esc_html__( 'Enable Arrows', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'enable_dots',
			[
				'label'   => esc_html__( 'Enable Dots', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		$this->add_render_attribute(
			'swiper', [
				'class'      => [ 'swiper-container', 'slider', 'slider-headings', 'js-slider-headings' ],
				'data-speed' => $settings['speed']['size'],
			]
		);

		if ( $settings['enable_autoplay'] ) {
			$this->add_render_attribute(
				'swiper', [
					'data-autoplay-enabled' => 'true',
					'data-autoplay-delay'   => $settings['autoplay_delay']['size'],
				]
			);
		}

		if ( $settings['enable_mousewheel_control'] ) {
			$this->add_render_attribute(
				'swiper', [
					'data-mousewheel-enabled' => 'true',
					'data-mousewheel-target'  => $settings['mousewheel_target'],
				]
			);
		}

		if ( $settings['enable_keyboard_control'] ) {
			$this->add_render_attribute(
				'swiper', [
					'data-keyboard-enabled' => 'true',
				]
			);
		}

		if ( $settings['enable_touch_control'] ) {
			$this->add_render_attribute(
				'swiper', [
					'data-touch-enabled' => 'true',
				]
			);
		}

		$this->get_posts();
		$posts = $this->posts;

		if ( $settings['posts_amount']['size'] > 0 ) {
			array_splice( $posts, $settings['posts_amount']['size'] );
		}

		?>

		<?php if ( ! empty( $posts ) ) : ?>
			<div class="section section-fullscreen-slider section-headings-slider section-fullheight" data-os-animation="data-os-animation">
				<div class="section-fullheight__inner section-fullscreen-slider__inner">
					<div <?php echo $this->get_render_attribute_string( 'swiper' ); ?>>
						<div class="swiper-wrapper">
							<?php foreach ( $posts as $item ) : ?>
								<?php $is_enabled = ( array_key_exists( 'enabled' . $item['id'], $settings ) ) && ( $settings[ 'enabled' . $item['id'] ] ); ?>
								<?php if ( $is_enabled ) : ?>
									<?php
									$attrs_link = '';

									if ( ! empty( $item['image'] ) ) {
										$attrs_link = 'data-pjax-link=fullscreenSlider';
									}
									?>
									<div class="swiper-slide slider-headings__slide">
										<a class="slider-headings__link" href="<?php echo esc_url( $item['permalink'] ); ?>" <?php echo esc_attr( $attrs_link ); ?> data-slide-id="<?php echo esc_attr( $item['id'] ); ?>">
											<h2 class="split-chars"><?php echo $item['title']; ?></h2>
											<?php if ( $item['description'] ) : ?>
												<p class="split-text"><?php echo $item['description']; ?></p>
											<?php endif; ?>
										</a>
									</div>
								<?php endif; ?>
							<?php endforeach; ?>
						</div>
						<div class="slider__backgrounds">
							<?php foreach ( $posts as $item ) : ?>
								<?php $is_enabled = ( array_key_exists( 'enabled' . $item['id'], $settings ) ) && ( $settings[ 'enabled' . $item['id'] ] ); ?>
								<?php if ( $is_enabled ) : ?>
									<?php if ( ! empty( $item['video'] ) ) : ?>
										<video class="slider__background of-cover" src="<?php echo esc_url( $item['video'] ); ?>" poster="<?php echo esc_url( $item['image'] ); ?>" playsinline loop muted autoplay data-background-for="<?php echo esc_attr( $item['id'] ); ?>"></video>
									<?php elseif ( ! empty( $item['image'] ) ) : ?>
										<div class="slider__background lazy-bg" data-src="<?php echo esc_url( $item['image'] ); ?>" data-background-for="<?php echo esc_attr( $item['id'] ); ?>"></div>
									<?php endif; ?>
								<?php endif; ?>
							<?php endforeach; ?>
							<div class="slider__background-overlay overlay overlay_dark"></div>
						</div>
						<!-- - background images -->
						<?php if ( $settings['enable_dots'] ) : ?>
							<div class="slider-headings__footer">
								<div class="slider__dots js-slider-headings__dots">
									<div class="slider__dot slider-headings__dot slider__dot_active"></div>
									<div class="slider__dot slider-headings__dot"></div>
									<div class="slider__dot slider-headings__dot"></div>
									<div class="slider__dot slider-headings__dot"></div>
								</div>
							</div>
							<!-- - dots -->
						<?php endif; ?>
						<?php if ( $settings['enable_counter'] ) : ?>
							<div class="slider__progress slider-headings__progress">
								<div class="swiper-container slider-headings__counter js-slider-headings-counter-current">
									<div class="swiper-wrapper"></div>
								</div>
							</div>
							<!-- - counter -->
						<?php endif; ?>
						<?php if ( $settings['enable_arrows'] ) : ?>
							<div class="slider__arrow slider-headings__arrow slider-headings__arrow_prev js-slider-headings__prev">
								<div class="slider__arrow-inner"><i class="material-icons">keyboard_arrow_left</i></div>
							</div>
							<div class="slider__arrow slider-headings__arrow slider-headings__arrow_next js-slider-headings__next">
								<div class="slider__arrow-inner"><i class="material-icons">keyboard_arrow_right</i></div>
							</div>
							<!-- - nav arrows -->
						<?php endif; ?>
					</div>
				</div>
			</div>
		<?php endif; ?>

		<?php
	}

}
