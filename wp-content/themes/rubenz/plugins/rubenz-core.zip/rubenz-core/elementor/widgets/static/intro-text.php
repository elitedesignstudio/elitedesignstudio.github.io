<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Intro_Text extends Widget_Base {

	public function get_name() {
		return 'rubenz-widget-intro-text';
	}

	public function get_title() {
		return esc_html__( 'Intro Text', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-plug';
	}

	public function get_categories() {
		return [ 'rubenz-static' ];
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {

		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = [
			'conditions' => [ 'widgetType' => $name ],
			'fields'     => [
				[
					'field'       => 'heading',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Content', 'rubenz' ) ),
					'editor_type' => 'AREA',
				],
			],
		];

		return $widgets;

	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', [ $this, 'wpml_widgets_to_translate_filter' ] );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'heading',
			[
				'label'       => esc_html__( 'Content', 'rubenz' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'Content...', 'rubenz' ),
			]
		);

		$this->add_control(
			'show_decoration_line',
			[
				'label'   => esc_html__( 'Show Line Decoration', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

		/**
		 * Section Animation
		 */
		$this->start_controls_section(
			'animation_section',
			[
				'label' => esc_html__( 'Animation', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		/**
		 * OS Animation
		 */
		$this->add_control(
			'enable_animation',
			[
				'label'   => esc_html__( 'Enable on-scroll animation', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'section', 'class', [ 'section-intro' ] );
		$this->add_render_attribute( 'heading', 'class', [ 'heading-light', 'split-text' ] );

		if ( $settings['enable_animation'] ) {
			$this->add_render_attribute( 'section', 'data-os-animation' );
		}

		$this->add_inline_editing_attributes( 'heading' );

		?>

		<div <?php echo $this->get_render_attribute_string( 'section' ); ?>>
			<div class="container-fluid">
				<header class="row section-intro__header">
					<div class="col">
						<h1 <?php echo $this->get_render_attribute_string( 'heading' ); ?>><?php echo $settings['heading']; ?></h1>
						<?php if ( $settings['show_decoration_line'] ) : ?>
							<div class="section-intro__headline"></div>
						<?php endif; ?>
					</div>
				</header>
			</div>
		</div>

		<?php
	}

	protected function _content_template() {

		?>

		<#

		view.addRenderAttribute( 'section', 'class', [ 'section-intro' ] );

		view.addInlineEditingAttributes( 'heading' );

		#>

		<div {{{ view.getRenderAttributeString( 'section' ) }}}>
			<div class="container-fluid">
				<header class="row section-intro__header">
					<div class="col">
						<h1 class="heading-light split-text">
							<span {{{ view.getRenderAttributeString( 'heading' ) }}}>{{{ settings.heading }}}</span></h1>
						<# if ( settings.show_decoration_line ) { #>
							<div class="section-intro__headline"></div>
						<# } #>
					</div>
				</header>
			</div>
		</div>

		<?php
	}

}
