<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Portfolio_Masonry_Grid extends Widget_Base {

	public function __construct( $data = [], $args = null ) {
		parent::__construct( $data, $args );
		$this->get_posts();
	}

	public function get_name() {
		return 'rubenz-widget-portfolio-masonry-grid';
	}

	public function get_title() {
		return esc_html__( 'Portfolio Masonry Grid', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-sitemap';
	}

	public function get_categories() {
		return [ 'rubenz-dynamic' ];
	}

	private $posts;
	private $post_type = '';

	private function get_posts() {

		$args = apply_filters('arts/elementor/rubenz_widget_portfolio_masonry_grid/query_args', array(
			'post_type'      => 'arts_portfolio_item',
			'posts_per_page' => -1,
		));

		$posts      = array();
		$taxonomies = array();
		$counter    = 0;

		$loop = new \WP_Query( $args );

		if ( $loop->have_posts() ) {

			while ( $loop->have_posts() ) {

				$loop->the_post();

				$post_link  = get_the_permalink();
				$post_image = get_post_thumbnail_id();

				$posts[ $counter ]['id']         = get_the_ID();
				$posts[ $counter ]['title']      = get_the_title();
				$posts[ $counter ]['permalink']  = $post_link;
				$posts[ $counter ]['image_id']   = $post_image;
				$post_categories                 = get_the_terms( $posts[ $counter ]['id'], 'arts_portfolio_category' );
				$posts[ $counter ]['categories'] = $post_categories;

				if ( is_array( $post_categories ) ) {
					foreach ( $post_categories as $item ) {

						$arr = array(
							'slug' => $item->slug,
							'name' => $item->name,
						);

						// don't add the same item multiple times
						if ( ! in_array( $arr, $taxonomies ) ) {
							array_push( $taxonomies, $arr );
						}
					}
				}

				$counter++;

			}

			wp_reset_postdata();

		}

		$this->posts      = $posts;
		$this->taxonomies = $taxonomies;
		$this->post_type  = array_key_exists('post_type', $args) ? $args['post_type'] : '';

	}

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$posts = $this->posts;
		$post_type = $this->post_type;

		foreach ( $posts as $index => $item ) {

			/**
			 * Heading Toggle
			 */
			$id = 'heading_toggle' . $item['id'];
			$this->add_control(
				$id,
				[
					'label'      => $item['title'],
					'type'       => Controls_Manager::HEADING,
					'conditions' => [
						'relation' => 'or',
						'terms'    => [
							[
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							],
							[
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							],
						],
					],
				]
			);

			/**
			 * Toggle
			 */
			$id = 'enabled' . $item['id'];
			$this->add_control(
				$id,
				[
					'label'      => esc_html__( 'Enabled', 'rubenz' ),
					'type'       => Controls_Manager::SWITCHER,
					'default'    => 'yes',
					'separator'  => 'after',
					'conditions' => [
						'relation' => 'or',
						'terms'    => [
							[
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							],
							[
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							],
						],
					],
				]
			);

		}

		$this->add_control(
			'dynamic_content_info',
			[
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => sprintf(
					'%1$s<br><br>%2$s <a href="%3$s" target="_blank">%4$s</a>',
					esc_html__( 'This widget displays content dynamically from the existing posts. It\'s not editable directly through Elementor Page Builder.', 'rubenz' ),
					esc_html__( 'You can edit your posts', 'rubenz' ),
					admin_url( 'edit.php?post_type=' . $post_type),
					esc_html__( 'in WordPress admin panel', 'rubenz' )
				),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
			]
		);

		$this->end_controls_section();

		/**
		 * Section Layout
		 */
		$this->start_controls_section(
			'layout_section',
			[
				'label' => esc_html__( 'Layout', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_LAYOUT,
			]
		);

		$this->add_control(
			'enable_fancy',
			[
				'label'     => esc_html__( 'Enable Fancy Grid', 'rubenz' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => array(
					'columns!' => '12',
				),
			]
		);

		/**
		 * Columns
		 */
		$this->add_responsive_control(
			'columns',
			[
				'label'           => esc_html__( 'Columns', 'rubenz' ),
				'type'            => Controls_Manager::SELECT,
				'options'         => [
					3  => esc_html__( 'Four Columns', 'rubenz' ),
					4  => esc_html__( 'Three Columns', 'rubenz' ),
					6  => esc_html__( 'Two Columns', 'rubenz' ),
					12 => esc_html__( 'Single Column', 'rubenz' ),
				],
				'render_type'     => 'template',
				'desktop_default' => 4,
				'tablet_default'  => 6,
				'mobile_default'  => 12,
			]
		);

		/**
		 * Space Between
		 */
		$this->add_responsive_control(
			'space_between',
			[
				'label'           => esc_html__( 'Space Between', 'rubenz' ),
				'type'            => Controls_Manager::SLIDER,
				'range'           => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 80,
				],
				'tablet_default'  => [
					'size' => 30,
				],
				'mobile_default'  => [
					'size' => 15,
				],
				'selectors'       => [
					'{{WRAPPER}}'                     => 'overflow: hidden;',
					'{{WRAPPER}} .grid'               => 'margin: calc(-{{SIZE}}{{UNIT}} / 2);',
					'{{WRAPPER}} .grid__item'         => 'padding: calc({{SIZE}}{{UNIT}} / 2) calc({{SIZE}}{{UNIT}} / 2);',
					'{{WRAPPER}} .grid__item_caption' => 'padding: calc({{SIZE}}{{UNIT}} / 2 - 1em) calc({{SIZE}}{{UNIT}} / 2);',
					'{{WRAPPER}} .grid_fancy .grid__item:nth-child(3)' => 'margin-top: {{SIZE}}{{UNIT}};',
					'(tablet){{WRAPPER}} .grid_fancy .grid__item:nth-child(3)' => 'margin-top: 0;',
					'(mobile){{WRAPPER}} .grid_fancy .grid__item:nth-child(3)' => 'margin-top: 0;',
				],
				'render_type'     => 'template',
			]
		);

		$this->end_controls_section();

		/**
		 * Section Animation
		 */
		$this->start_controls_section(
			'animation_section',
			[
				'label' => esc_html__( 'Animation', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'image_parallax',
			[
				'label'   => esc_html__( 'Enable parallax', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'image_parallax_speed',
			[
				'label'     => esc_html__( 'Parallax Speed', 'rubenz' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'factor' => [
						'min'  => -0.5,
						'max'  => 0.5,
						'step' => 0.01,
					],
				],
				'default'   => [
					'unit' => 'factor',
					'size' => 0.1,
				],
				'condition' => [
					'image_parallax' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'settings_section',
			[
				'label' => esc_html__( 'Posts', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			]
		);

		$this->add_control(
			'posts_amount',
			[
				'label'   => esc_html__( 'Number of Posts to Display (0 for all)', 'rubenz' ),
				'type'    => Controls_Manager::SLIDER,
				'range'   => [
					'number' => [
						'min'  => 0,
						'max'  => 16,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'number',
					'size' => 0,
				],
			]
		);

		$this->add_control(
			'enable_filter',
			[
				'label' => esc_html__( 'Enable Grid Filter', 'rubenz' ),
				'type'  => Controls_Manager::SWITCHER,
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		$col_desktop = 'grid__item_desktop-' . $settings['columns'];
		$col_tablet  = 'grid__item_tablet-' . $settings['columns_tablet'];
		$col_mobile  = 'grid__item_mobile-' . $settings['columns_mobile'];

		$this->add_render_attribute(
			'section', [
				'class'                    => [ 'grid', 'js-grid' ],
				'data-grid-columns'        => 12 / $settings['columns'],
				'data-grid-columns-tablet' => 12 / $settings['columns_tablet'],
				'data-grid-columns-mobile' => 12 / $settings['columns_mobile'],
			]
		);

		$this->add_render_attribute(
			'sizerAtts', [
				'class' => [ 'grid__sizer', 'js-grid__sizer', $col_desktop, $col_tablet, $col_mobile ],
			]
		);

		if ( $settings['enable_fancy'] ) {

			$this->add_render_attribute(
				'section', [
					'class' => [ 'grid_fancy', 'js-grid' ],
				]
			);

		}

		$this->get_posts();
		$posts      = $this->posts;
		$taxonomies = $this->taxonomies;

		if ( $settings['posts_amount']['size'] > 0 ) {
			array_splice( $posts, $settings['posts_amount']['size'] );
		}

		?>

		<?php if ( ! empty( $posts ) ) : ?>

			<?php if ( ! empty( $taxonomies && $settings['enable_filter'] ) ) : ?>
				<div class="filter js-filter">
					<div class="filter__inner">
						<div class="row">
							<div class="col-xl-auto col-12 filter__item filter__item_active js-filter__item" data-filter="*">
								<div><?php esc_html_e( 'All', 'rubenz' ); ?></div>
							</div>
							<?php foreach ( $taxonomies as $item ) : ?>
								<div class="col-xl-auto col-12 filter__item js-filter__item" data-filter=".category-<?php echo $item['slug']; ?>">
									<div><?php echo $item['name']; ?></div>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
			<?php endif; ?>

			<div <?php echo $this->get_render_attribute_string( 'section' ); ?>>
				<div <?php echo $this->get_render_attribute_string( 'sizerAtts' ); ?>></div>
					<?php foreach ( $posts as $index => $item ) : ?>
						<?php $is_enabled = ( array_key_exists( 'enabled' . $item['id'], $settings ) ) && ( $settings[ 'enabled' . $item['id'] ] ); ?>
						<?php if ( $is_enabled ) : ?>
							<?php

							$index++;
							if ( $index < 10 ) {
								$counter = '00' . $index;
							} else {
								$counter = '0' . $index;
							}

							$img = wp_get_attachment_image_src( $item['image_id'], 'full' );

							$this->add_render_attribute(
								'wrapper', array(
									'class' => 'lazy',
									'style' => 'padding-bottom: calc( (' . $img[2] . '/' . $img[1] . ') * 100% ); height: 0;',
								), true, true
							);

							if ( $settings['image_parallax'] ) {

								$this->add_render_attribute(
									'wrapper', array(
										'data-art-parallax' => 'true',
										'data-art-parallax-factor' => $settings['image_parallax_speed']['size'],
									), true, true
								);

							}

							$this->add_render_attribute(
								'itemAtts' . $index, [
									'class' => [ 'grid__item', 'js-grid__item', $col_desktop, $col_tablet, $col_mobile ],
								]
							);

							$this->add_render_attribute(
								'linkAtts', [
									'class'          => 'figure-portfolio',
									'href'           => $item['permalink'],
									'data-post-id'   => $item['id'],
									'data-pjax-link' => empty( $item['image_id'] ) ? '' : 'masonryGrid',
								], true, true
							);

							// categories
							if ( array_key_exists( 'categories', $item ) && is_array( $item['categories'] ) ) {

								$categories = array();

								foreach ( $item['categories'] as $taxonomy ) {

									$this->add_render_attribute(
										'itemAtts' . $index, [
											'class' => 'category-' . esc_attr( $taxonomy->slug ),
										]
									);
									$categories[] .= $taxonomy->name;

								}
							}

							?>
							<div <?php echo $this->get_render_attribute_string( 'itemAtts' . $index ); ?>>
								<a <?php echo $this->get_render_attribute_string( 'linkAtts' ); ?>>
									<div class="figure-portfolio__counter"><?php echo $counter; ?></div>
									<div class="figure-portfolio__content">
										<div class="figure-portfolio__wrapper-img">
											<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
												<img src='#' data-src="<?php echo esc_url( $img[0] ); ?>" alt=""/>
											</div>
										</div>
										<?php if ( ! empty( $item['title'] ) ) : ?>
											<h3><?php echo $item['title']; ?></h3>
										<?php endif; ?>
									</div>
								</a>
							</div>
						<?php endif; ?>
					<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<?php
	}

}
