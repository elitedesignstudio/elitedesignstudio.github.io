<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Parallax_Background extends Widget_Base {

	public function get_name() {
		return 'rubenz-widget-parallax-background';
	}

	public function get_title() {
		return esc_html__( 'Parallax Background', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-plug';
	}

	public function get_categories() {
		return [ 'rubenz-static' ];
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {

		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = [
			'conditions' => [ 'widgetType' => $name ],
			'fields'     => [
				[
					'field'       => 'caption',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Caption', 'rubenz' ) ),
					'editor_type' => 'LINE',
				],
			],
		];

		return $widgets;

	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', [ $this, 'wpml_widgets_to_translate_filter' ] );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'image',
			[
				'label'   => esc_html__( 'Choose Image', 'rubenz' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'image_placement',
			[
				'label'     => esc_html__( 'Image Placement', 'rubenz' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'image'      => [
						'title' => esc_html__( 'Normal Image', 'rubenz' ),
						'icon'  => 'fa fa-fw fa-file-image-o',
					],
					'background' => [
						'title' => esc_html__( 'Background', 'rubenz' ),
						'icon'  => 'fa fa-fw fa-picture-o',
					],
				],
				'default'   => 'image',
				'toggle'    => false,
				'condition' => [
					'image!' => array(
						'id'  => '',
						'url' => '',
					),
				],
			]
		);

		$this->add_responsive_control(
			'min_height',
			[
				'label'           => esc_html__( 'Background Height', 'rubenz' ),
				'type'            => Controls_Manager::SLIDER,
				'desktop_default' => [
					'size' => 800,
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => 70,
					'unit' => 'vh',
				],
				'mobile_default'  => [
					'size' => 50,
					'unit' => 'vh',
				],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1440,
					],
					'vh' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'size_units'      => [ 'px', 'vh' ],
				'selectors'       => [
					'{{WRAPPER}} .section-image__wrapper' => 'height: 1px; min-height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .section-image__wrapper:after' => 'content: ""; min-height: inherit;', // Hack for IE11
				],
				'condition'       => [
					'image_placement' => 'background',
					'image!'          => array(
						'id'  => '',
						'url' => '',
					),
				],
			]
		);

		$this->add_control(
			'image_parallax',
			[
				'label'     => esc_html__( 'Enable parallax', 'rubenz' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => [
					'image!' => array(
						'id'  => '',
						'url' => '',
					),
				],
			]
		);

		$this->add_control(
			'image_parallax_speed',
			[
				'label'     => esc_html__( 'Parallax Speed', 'rubenz' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'factor' => [
						'min'  => -0.5,
						'max'  => 0.5,
						'step' => 0.01,
					],
				],
				'default'   => [
					'unit' => 'factor',
					'size' => 0.1,
				],
				'condition' => [
					'image_parallax' => 'yes',
					'image!'         => array(
						'id'  => '',
						'url' => '',
					),
				],
			]
		);

		$this->add_control(
			'caption',
			[
				'label'       => esc_html__( 'Caption', 'rubenz' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Caption...', 'rubenz' ),
				'condition'   => [
					'image!' => array(
						'id'  => '',
						'url' => '',
					),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'layout_section',
			[
				'label' => esc_html__( 'Layout', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_LAYOUT,
			]
		);

		$this->add_control(
			'layout',
			[
				'label'   => esc_html__( 'Image Alignment', 'rubenz' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'section text-center'       => [
						'title' => esc_html__( 'Fullwidth', 'rubenz' ),
						'icon'  => 'fa fa-fw fa-arrows-h',
					],
					'section_w-container-left'  => [
						'title' => esc_html__( 'Left', 'rubenz' ),
						'icon'  => 'fa fa-fw fa-align-left',
					],
					'container text-center'     => [
						'title' => esc_html__( 'Center', 'rubenz' ),
						'icon'  => 'fa fa-fw fa-align-center',
					],
					'section_w-container-right' => [
						'title' => esc_html__( 'Right', 'rubenz' ),
						'icon'  => 'fa fa-fw fa-align-right',
					],
				],
				'default' => 'section text-center',
				'toggle'  => false,
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'caption' );

		$this->add_render_attribute( 'section', 'class', [ 'section-image', $settings['layout'] ] );
		$this->add_render_attribute( 'wrapper', 'class', 'section-image__wrapper' );
		$this->add_render_attribute(
			'img', array(
				'class'    => [ 'lazy-bg' ],
				'data-src' => $settings['image']['url'],
			)
		);

		if ( $settings['image_parallax'] ) {

			$this->add_render_attribute(
				'wrapper', array(
					'data-art-parallax'        => 'true',
					'data-art-parallax-factor' => $settings['image_parallax_speed']['size'],
				)
			);

			$this->add_render_attribute( 'img', 'class', 'art-parallax__bg' );
		}

		if ( ! empty( $settings['image']['url'] ) && $settings['image_placement'] == 'image' ) {

			$img = wp_get_attachment_image_src( $settings['image']['id'], 'full' );

			$this->add_render_attribute(
				'wrapper', array(
					'class' => 'lazy',
					'style' => 'padding-bottom: calc( (' . $img[2] . '/' . $img[1] . ') * 100% ); height: 0;',
				)
			);

			$this->add_render_attribute(
				'img', array(
					'class' => '',
					'src'   => '#',
					'alt'   => '',
				), true, true
			);

		}

		?>

		<div <?php echo $this->get_render_attribute_string( 'section' ); ?>>
			<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
				<?php if ( $settings['image_placement'] == 'background' ) : ?>
					<div <?php echo $this->get_render_attribute_string( 'img' ); ?>></div>
				<?php elseif ( $settings['image_placement'] == 'image' ) : ?>
					<img <?php echo $this->get_render_attribute_string( 'img' ); ?>>
				<?php endif; ?>
			</div>
			<?php if ( ! empty( $settings['caption'] ) ) : ?>
				<h5 <?php echo $this->get_render_attribute_string( 'caption' ); ?>><?php echo $settings['caption']; ?></h5>
			<?php endif; ?>
		</div>

		<?php
	}

	protected function _content_template() {

		?>

		<#
			view.addInlineEditingAttributes( 'caption' );

			view.addRenderAttribute( 'section', 'class', [ 'section-image', settings.layout ] );

			view.addRenderAttribute( 'wrapper', {
				'class': 'section-image__wrapper'
			});

			view.addRenderAttribute('img', {
				'class': 'lazy-bg',
				'data-src': settings.image.url,
			});

			if ( settings.image_parallax ) {

				view.addRenderAttribute(
					'wrapper', {
						'data-art-parallax': 'true',
						'data-art-parallax-factor': settings.image_parallax_speed.size,
					}
				);

				view.addRenderAttribute( 'img', 'class', 'art-parallax__bg' );

			}

			if ( settings.image_placement == 'image' ) {

				view.addRenderAttribute(
					'wrapper', {
						'class': 'lazy'
					}
				);

				view.addRenderAttribute(
					'img', {
						'class': '',
						'src': '#',
						'alt': '',
					}, true, true
				);

			}

		#>

		<div {{{ view.getRenderAttributeString( 'section' ) }}}>
			<div {{{ view.getRenderAttributeString( 'wrapper' ) }}}>
				<# if ( settings.image_placement == 'background' ) { #>
					<div {{{ view.getRenderAttributeString( 'img' ) }}}></div>
				<# } else if (settings.image_placement == 'image') { #>
					<img {{{ view.getRenderAttributeString( 'img' ) }}} >
				<# } #>
			</div>
			<# if ( settings.caption ) { #>
				<h5 {{{ view.getRenderAttributeString( 'caption' ) }}}>{{{ settings.caption }}}</h5>
			<# } #>
		</div>

		<?php
	}


}
