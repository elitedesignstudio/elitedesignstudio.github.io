<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Logo_Description extends Widget_Base {

	public function get_name() {
		return 'rubenz-widget-logo-description';
	}

	public function get_title() {
		return esc_html__( 'Logo with Description', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-plug';
	}

	public function get_categories() {
		return [ 'rubenz-static' ];
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {

		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = [
			'conditions' => [ 'widgetType' => $name ],
			'fields'     => [
				[
					'field'       => 'description',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Short Description', 'rubenz' ) ),
					'editor_type' => 'LINE',
				],
			],
		];

		return $widgets;

	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', [ $this, 'wpml_widgets_to_translate_filter' ] );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'image',
			[
				'label'   => esc_html__( 'Choose Image', 'rubenz' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'description',
			[
				'label'   => esc_html__( 'Short Description', 'rubenz' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Company...', 'rubenz' ),
			]
		);

		$this->add_control(
			'enable_grayscale',
			[
				'label'        => esc_html__( 'Enable Grayscale Filter', 'rubenz' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'grayscale',
				'default'      => 'grayscale',
			]
		);

		$this->add_control(
			'background_theme',
			[
				'label'   => esc_html__( 'Background Color Theme', 'rubenz' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					''                      => esc_html__( 'None', 'rubenz' ),
					'bg-white'              => esc_html__( 'Pure White', 'rubenz' ),
					'bg-light-grey'         => esc_html__( 'Light 1', 'rubenz' ),
					'bg-light'              => esc_html__( 'Light 2', 'rubenz' ),
					'bg-blue-grey'          => esc_html__( 'Blue Grey 1', 'rubenz' ),
					'bg-blue-grey-dark'     => esc_html__( 'Blue Grey 2', 'rubenz' ),
					'bg-dark color-white'   => esc_html__( 'Dark 1', 'rubenz' ),
					'bg-dark-2 color-white' => esc_html__( 'Dark 2', 'rubenz' ),
					'bg-black color-white'  => esc_html__( 'Dark 3', 'rubenz' ),
				],
				'default' => 'bg-light-grey',
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'description' );

		$this->add_render_attribute( 'section', 'class', [ 'figure-logo', $settings['enable_grayscale'], $settings['background_theme'] ] );

		?>

		<?php if ( ! empty( $settings['image']['url'] ) ) : ?>
			<?php

				$img = wp_get_attachment_image_src( $settings['image']['id'], 'full' );

				$this->add_render_attribute(
					'wrapper', array(
						'class' => 'lazy',
						'style' => 'padding-bottom: calc( (' . $img[2] . '/' . $img[1] . ') * 100% ); height: 0;',
					)
				);

				$this->add_render_attribute(
					'img', array(
						'data-src' => $settings['image']['url'],
						'src'      => '#',
						'alt'      => '',
					)
				);

			?>
			<div <?php echo $this->get_render_attribute_string( 'section' ); ?>>
				<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
					<img <?php echo $this->get_render_attribute_string( 'img' ); ?>>
				</div>
				<?php if ( ! empty( $settings['description'] ) ) : ?>
					<div class="figure-logo__description">
						<p <?php echo $this->get_render_attribute_string( 'description' ); ?>><?php echo $settings['description']; ?></p>
						<div class="figure-logo__line"></div>
					</div>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<?php
	}

	protected function _content_template() {

		?>

		<#

		view.addInlineEditingAttributes( 'description' );

		view.addRenderAttribute( 'section', 'class', [ 'figure-logo', settings.enable_grayscale, settings.background_theme ] );

		#>

		<# if ( settings.image.url ) { #>
			<#

				view.addRenderAttribute(
					'wrapper', {
						'class': 'lazy',
					}
				);

				view.addRenderAttribute(
					'img', {
						'data-src': settings.image.url,
						'src': '#',
						'alt': '',
					}
				);

			#>
			<div {{{ view.getRenderAttributeString( 'section' ) }}}>
				<div {{{ view.getRenderAttributeString( 'wrapper' ) }}}>
					<img {{{ view.getRenderAttributeString( 'img' ) }}}>
				</div>
				<# if ( settings.description ) { #>
					<div class="figure-logo__description">
						<p {{{ view.getRenderAttributeString( 'description' ) }}}>{{{ settings.description }}}</p>
						<div class="figure-logo__line"></div>
					</div>
				<# } #>
			</div>
		<# } #>

		<?php
	}

}
