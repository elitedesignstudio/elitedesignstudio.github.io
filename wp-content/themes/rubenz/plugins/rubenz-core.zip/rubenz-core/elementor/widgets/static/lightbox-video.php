<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Lightbox_Video extends Widget_Base {

	public function get_name() {
		return 'rubenz-widget-lightbox-video';
	}

	public function get_title() {
		return esc_html__( 'Lightbox Video', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-plug';
	}

	public function get_categories() {
		return [ 'rubenz-static' ];
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {

		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = [
			'conditions' => [ 'widgetType' => $name ],
			'fields'     => [
				[
					'field'       => 'link',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Video URL', 'rubenz' ) ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'heading',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Heading', 'rubenz' ) ),
					'editor_type' => 'LINE',
				],
			],
		];

		return $widgets;

	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', [ $this, 'wpml_widgets_to_translate_filter' ] );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'image_section',
			[
				'label' => esc_html__( 'Background', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'image',
			[
				'label'   => esc_html__( 'Background Image', 'rubenz' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'image_parallax',
			[
				'label'     => esc_html__( 'Enable parallax', 'rubenz' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => [
					'image!' => array(
						'id'  => '',
						'url' => '',
					),
				],
			]
		);

		$this->add_control(
			'image_parallax_speed',
			[
				'label'     => esc_html__( 'Parallax Speed', 'rubenz' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'factor' => [
						'min'  => -0.5,
						'max'  => 0.5,
						'step' => 0.01,
					],
				],
				'default'   => [
					'unit' => 'factor',
					'size' => 0.1,
				],
				'condition' => [
					'image_parallax' => 'yes',
					'image!'         => array(
						'id'  => '',
						'url' => '',
					),
				],
			]
		);

		$this->add_control(
			'image_overlay_opacity',
			[
				'label'     => esc_html__( 'Image Overlay Opacity', 'rubenz' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => .6,
				],
				'range'     => [
					'px' => [
						'max'  => 1,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .section-video__overlay' => 'opacity: {{SIZE}};',
				],
				'condition' => [
					'image!' => array(
						'id'  => '',
						'url' => '',
					),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'video_section',
			[
				'label' => esc_html__( 'Video', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'link',
			[
				'label'         => esc_html__( 'Video URL', 'rubenz' ),
				'type'          => Controls_Manager::URL,
				'show_external' => false,
				'placeholder'   => sprintf( '%1s: %2s', esc_html__( 'Example', 'rubenz' ), 'https://youtu.be/watch?v=BsekcY04xvQ' ),
			]
		);

		$this->add_control(
			'heading',
			[
				'label'       => esc_html__( 'Heading', 'rubenz' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Video...', 'rubenz' ),
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'section', 'class', [ 'section-video', 'section_pt', 'section_pb', 'bg-black-0', 'color-white' ] );

		$this->add_render_attribute(
			'img', array(
				'class'    => [ 'lazy-bg', 'art-parallax__bg' ],
				'data-src' => $settings['image']['url'],
			)
		);

		if ( $settings['image_parallax'] ) {

			$this->add_render_attribute(
				'section', array(
					'data-art-parallax'        => 'true',
					'data-art-parallax-factor' => $settings['image_parallax_speed']['size'],
				)
			);

		}

		$this->add_inline_editing_attributes( 'heading' );

		?>

		<div <?php echo $this->get_render_attribute_string( 'section' ); ?>>
			<a class="container section-video__link mfp-iframe js-video" href="<?php echo $settings['link']['url']; ?>">
				<?php if ( ! empty( $settings['heading'] ) ) : ?>
					<h2 <?php echo $this->get_render_attribute_string( 'heading' ); ?>><?php echo $settings['heading']; ?></h2>
				<?php endif; ?>
				<div class="section-video__icon material-icons">play_arrow</div>
			</a>
			<?php if ( ! empty( $settings['image']['url'] ) ) : ?>
				<div <?php echo $this->get_render_attribute_string( 'img' ); ?>>
					<div class="overlay overlay_dark section-video__overlay"></div>
				</div>
			<?php endif; ?>
		</div>

		<?php
	}

	protected function _content_template() {

		?>

		<#

			view.addRenderAttribute( 'section', 'class', [ 'section-video', 'section_pt', 'section_pb', 'bg-black-0', 'color-white' ] );

			view.addRenderAttribute(
				'img', {
					'class': [ 'lazy-bg', 'art-parallax__bg' ],
					'data-src': settings.image.url,
				}
			);

			if ( settings.image_parallax ) {

				view.addRenderAttribute(
					'section', {
						'data-art-parallax': 'true',
						'data-art-parallax-factor': settings.image_parallax_speed.size,
					}
				);

			}

			view.addInlineEditingAttributes( 'heading' );

		#>

		<div {{{ view.getRenderAttributeString( 'section' ) }}}>
			<a class="container section-video__link mfp-iframe js-video" href="{{{ settings.link.url }}}">
				<# if ( settings.heading ) { #>
					<h2 {{{ view.getRenderAttributeString( 'heading' ) }}}>{{{ settings.heading }}}</h2>
				<# } #>
				<div class="section-video__icon material-icons">play_arrow</div>
			</a>
			<# if ( settings.image.url ) { #>
				<div {{{ view.getRenderAttributeString( 'img' ) }}}>
					<div class="overlay overlay_dark section-video__overlay"></div>
				</div>
			<# } #>
		</div>

		<?php
	}

}
