<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Portfolio_Fullscreen_Two_Rows_Slider extends Widget_Base {

	public function __construct( $data = [], $args = null ) {
		parent::__construct( $data, $args );
		$this->get_posts();
	}

	public function get_name() {
		return 'rubenz-widget-portfolio-fullscreen-two-rows-slider';
	}

	public function get_title() {
		return esc_html__( 'Portfolio Fullscreen Two Rows Slider', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-sitemap';
	}

	public function get_categories() {
		return [ 'rubenz-dynamic' ];
	}

	private $posts;
	private $post_type = '';

	private function get_posts() {

		$args = apply_filters('arts/elementor/rubenz_widget_portfolio_fullscreen_two_rows_slider/query_args', array(
			'post_type'      => 'arts_portfolio_item',
			'posts_per_page' => -1,
		));

		$posts   = array();
		$counter = 0;

		$loop = new \WP_Query( $args );

		if ( $loop->have_posts() ) {

			while ( $loop->have_posts() ) {

				$loop->the_post();

				$post_link  = get_the_permalink();
				$post_image = get_the_post_thumbnail_url();

				$posts[ $counter ]['id']        = get_the_ID();
				$posts[ $counter ]['title']     = get_the_title();
				$posts[ $counter ]['permalink'] = $post_link;
				$posts[ $counter ]['image']     = $post_image;

				$counter++;

			}

			wp_reset_postdata();

		}

		$this->posts = $posts;
		$this->post_type  = array_key_exists('post_type', $args) ? $args['post_type'] : '';

	}

	public function wpml_widgets_to_translate_filter( $widgets ) {

		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = [
			'conditions' => [ 'widgetType' => $name ],
			'fields'     => [
				[
					'field'       => 'label_normal',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Helper Label Normal', 'rubenz' ) ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'label_hover',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Helper Label Hover', 'rubenz' ) ),
					'editor_type' => 'LINE',
				],
			],
		];

		return $widgets;

	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', [ $this, 'wpml_widgets_to_translate_filter' ] );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$posts = $this->posts;
		$post_type = $this->post_type;

		foreach ( $posts as $index => $item ) {

			/**
			 * Heading Toggle
			 */
			$id = 'heading_toggle' . $item['id'];
			$this->add_control(
				$id,
				[
					'label'      => $item['title'],
					'type'       => Controls_Manager::HEADING,
					'conditions' => [
						'relation' => 'or',
						'terms'    => [
							[
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							],
							[
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							],
						],
					],
				]
			);

			/**
			 * Toggle
			 */
			$id = 'enabled' . $item['id'];
			$this->add_control(
				$id,
				[
					'label'      => esc_html__( 'Enabled', 'rubenz' ),
					'type'       => Controls_Manager::SWITCHER,
					'default'    => 'yes',
					'separator'  => 'after',
					'conditions' => [
						'relation' => 'or',
						'terms'    => [
							[
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							],
							[
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							],
						],
					],
				]
			);

		}

		$this->add_control(
			'heading',
			[
				'label' => esc_html__( 'Helper', 'rubenz' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'label_normal',
			[
				'label'   => esc_html__( 'Title Normal', 'rubenz' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Scroll / Drag', 'rubenz' ),
			]
		);

		$this->add_control(
			'label_hover',
			[
				'label'   => esc_html__( 'Title Hover', 'rubenz' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Explore Project', 'rubenz' ),
			]
		);

		$this->add_control(
			'dynamic_content_info',
			[
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => sprintf(
					'%1$s<br><br>%2$s <a href="%3$s" target="_blank">%4$s</a>',
					esc_html__( 'This widget displays content dynamically from the existing posts. It\'s not editable directly through Elementor Page Builder.', 'rubenz' ),
					esc_html__( 'You can edit your posts', 'rubenz' ),
					admin_url( 'edit.php?post_type=' . $post_type),
					esc_html__( 'in WordPress admin panel', 'rubenz' )
				),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'settings_section',
			[
				'label' => esc_html__( 'Posts', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			]
		);

		$this->add_control(
			'posts_amount',
			[
				'label'   => esc_html__( 'Number of Posts to Display (0 for all)', 'rubenz' ),
				'type'    => Controls_Manager::SLIDER,
				'range'   => [
					'number' => [
						'min'  => 0,
						'max'  => 16,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'number',
					'size' => 0,
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'slider_section',
			[
				'label' => esc_html__( 'Slider', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			]
		);
		$this->add_control(
			'enable_mousewheel_control',
			[
				'label'   => esc_html__( 'Mousewheel Control', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'mousewheel_target',
			[
				'label'     => esc_html__( 'Mousewheel Events Target', 'rubenz' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '.page-wrapper',
				'options'   => [
					'.page-wrapper' => esc_html__( 'Page Wrapper', 'rubenz' ),
					'container'     => esc_html__( 'Container', 'rubenz' ),
				],
				'condition' => [
					'enable_mousewheel_control' => 'yes',
				],
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		$this->add_render_attribute(
			'slider', [
				'class' => [ 'slider', 'slider-text', 'js-slider-text' ],
			]
		);

		if ( $settings['enable_mousewheel_control'] ) {
			$this->add_render_attribute(
				'slider', [
					'data-mousewheel-enabled' => 'true',
					'data-mousewheel-target'  => $settings['mousewheel_target'],
				]
			);
		}

		$this->get_posts();

		$posts = $this->posts;

		if ( $settings['posts_amount']['size'] > 0 ) {
			array_splice( $posts, $settings['posts_amount']['size'] );
		}

		$posts_reverse = array_reverse( $posts );
		$amount        = count( $posts );
		$amount++;

		?>

		<?php if ( ! empty( $posts ) ) : ?>
			<div class="section section-fullscreen-slider section-text-slider section-fullheight" data-os-animation="data-os-animation">
				<div class="section-fullheight__inner section-fullscreen-slider__inner">
					<div <?php echo $this->get_render_attribute_string( 'slider' ); ?>>
						<div class="swiper-container slider-text__upper js-slider-text__upper">
							<div class="swiper-wrapper">
								<?php foreach ( $posts as $index => $item ) : ?>
									<?php $is_enabled = ( array_key_exists( 'enabled' . $item['id'], $settings ) ) && ( $settings[ 'enabled' . $item['id'] ] ); ?>
									<?php if ( $is_enabled ) : ?>
										<?php
										$attrs_link = '';
										$index++;
										if ( $index < 10 ) {
											$counter = '00' . $index;
										} else {
											$counter = '0' . $index;
										}

										if ( ! empty( $item['image'] ) ) {
											$attrs_link = 'data-pjax-link=fullscreenSlider';
										}
										?>
										<div class="swiper-slide slider-text__slide">
											<a class="slider-text__link" href="<?php echo esc_url( $item['permalink'] ); ?>" <?php echo esc_attr( $attrs_link ); ?> data-slide-id="<?php echo esc_attr( $item['id'] ); ?>">
												<div class="slider-text__line"></div>
												<header class="slider-text__header">
													<div class="slider-text__counter split-chars"><?php echo $counter; ?></div>
													<h2 class="split-chars"><?php echo $item['title']; ?></h2>
												</header>
											</a>
										</div>
									<?php endif; ?>
								<?php endforeach; ?>
							</div>
						</div>
						<!-- - upper line-->
						<div class="swiper-container slider-text__lower js-slider-text__lower" dir="rtl">
							<div class="swiper-wrapper">
								<?php foreach ( $posts_reverse as $index => $item ) : ?>
									<?php $is_enabled = ( array_key_exists( 'enabled' . $item['id'], $settings ) ) && ( $settings[ 'enabled' . $item['id'] ] ); ?>
									<?php if ( $is_enabled ) : ?>
										<?php
										$attrs_link = '';
										$amount--;
										if ( $amount < 10 ) {
											$counter = '00' . $amount;
										} else {
											$counter = '0' . $amount;
										}

										if ( ! empty( $item['image'] ) ) {
											$attrs_link = 'data-pjax-link=fullscreenSlider';
										}
										?>
										<div class="swiper-slide slider-text__slide" dir="ltr">
											<a class="slider-text__link" href="<?php echo esc_url( $item['permalink'] ); ?>" <?php echo esc_attr( $attrs_link ); ?> data-slide-id="<?php echo esc_attr( $item['id'] ); ?>">
												<div class="slider-text__line"></div>
												<header class="slider-text__header">
													<div class="slider-text__counter split-chars"><?php echo $counter; ?></div>
													<h2 class="split-chars"><?php echo $item['title']; ?></h2>
												</header>
											</a>
										</div>
									<?php endif; ?>
								<?php endforeach; ?>
							</div>
						</div>
						<!-- - lower line -->
						<?php if ( ! empty( $settings['label_normal'] ) && ! empty( $settings['label_hover'] ) ) : ?>
							<div class="slider-text__helper">
								<div class="slider-text__helper__inner">
									<div class="slider-text__helper-icon slider-text__helper-icon_left material-icons">keyboard_arrow_left</div>
									<div class="slider-text__helper-label-normal split-chars"><?php echo $settings['label_normal']; ?></div>
									<div class="slider-text__helper-label-view split-chars"><?php echo $settings['label_hover']; ?></div>
									<div class="slider-text__helper-icon slider-text__helper-icon_right material-icons">keyboard_arrow_right</div>
								</div>
							</div>
							<!-- - helper -->
						<?php endif; ?>
						<div class="slider__backgrounds">
							<?php foreach ( $posts as $item ) : ?>
								<?php $is_enabled = ( array_key_exists( 'enabled' . $item['id'], $settings ) ) && ( $settings[ 'enabled' . $item['id'] ] ); ?>
								<?php if ( $is_enabled ) : ?>
									<?php if ( ! empty( $item['image'] ) ) : ?>
										<div class="slider__background lazy-bg" data-src="<?php echo esc_url( $item['image'] ); ?>" data-background-for="<?php echo esc_attr( $item['id'] ); ?>"></div>
									<?php endif; ?>
								<?php endif; ?>
							<?php endforeach; ?>
							<div class="slider__background-overlay overlay overlay_dark"></div>
						</div>
						<!-- - background images -->
					</div>
				</div>
			</div>
		<?php endif; ?>

		<?php
	}

}
