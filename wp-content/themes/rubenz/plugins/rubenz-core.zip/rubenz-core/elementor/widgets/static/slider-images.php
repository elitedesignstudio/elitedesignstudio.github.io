<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Slider_Images extends Widget_Base {

	public function get_name() {
		return 'rubenz-widget-slider-images';
	}

	public function get_title() {
		return esc_html__( 'Slider Images', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-plug';
	}

	public function get_categories() {
		return [ 'rubenz-static' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Images', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'images_gallery',
			[
				'type'    => Controls_Manager::GALLERY,
				'default' => [],
			]
		);

		$this->add_control(
			'enable_captions',
			[
				'label'   => esc_html__( 'Enable Image Captions', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'captions_position',
			[
				'label'     => esc_html__( 'Captions Position', 'rubenz' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'slider__caption_top'    => [
						'title' => esc_html__( 'Top', 'rubenz' ),
						'icon'  => 'fa fa-fw fa-long-arrow-up',
					],
					'slider__caption_bottom' => [
						'title' => esc_html__( 'Bottom', 'rubenz' ),
						'icon'  => 'fa fa-fw fa-long-arrow-down',
					],
				],
				'default'   => 'slider__caption_top',
				'toggle'    => false,
				'condition' => [
					'enable_captions' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		/**
		 * Section Slider
		 */
		$this->start_controls_section(
			'slider_section',
			[
				'label' => esc_html__( 'Slider', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			]
		);

		$this->add_responsive_control(
			'slides_per_view',
			[
				'label'           => esc_html__( 'Slides Per Screen', 'rubenz' ),
				'type'            => Controls_Manager::SLIDER,
				'range'           => [
					'number' => [
						'min'  => 1,
						'max'  => 4,
						'step' => 1,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 3.5,
					'unit' => 'number',
				],
				'tablet_default'  => [
					'size' => 1.33,
					'unit' => 'number',
				],
				'mobile_default'  => [
					'size' => 1.33,
					'unit' => 'number',
				],
			]
		);

		$this->add_responsive_control(
			'centered_slides',
			[
				'label'           => esc_html__( 'Horizontaly Centered Slides', 'rubenz' ),
				'label_block'     => true,
				'type'            => Controls_Manager::SWITCHER,
				'desktop_default' => true,
				'tablet_default'  => true,
				'mobile_default'  => true,
			]
		);

		$this->add_control(
			'vertical_centered_slides',
			[
				'label'   => esc_html__( 'Vertically Centered Slides', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_responsive_control(
			'space_between',
			[
				'label'           => esc_html__( 'Space Between Slides', 'rubenz' ),
				'type'            => Controls_Manager::SLIDER,
				'range'           => [
					'px' => [
						'min'  => 0,
						'max'  => 160,
						'step' => 1,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 30,
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => 15,
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => 15,
					'unit' => 'px',
				],
			]
		);

		$this->add_control(
			'enable_progress',
			[
				'label'   => esc_html__( 'Enable Progress Bar', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'enable_autoplay',
			[
				'label'   => esc_html__( 'Autoplay', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'autoplay_delay',
			[
				'label'     => esc_html__( 'Autoplay Delay (ms)', 'rubenz' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'ms' => [
						'min'  => 1000,
						'max'  => 60000,
						'step' => 100,
					],
				],
				'default'   => [
					'unit' => 'ms',
					'size' => 6000,
				],
				'condition' => [
					'enable_autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'speed',
			[
				'label'   => esc_html__( 'Speed', 'rubenz' ),
				'type'    => Controls_Manager::SLIDER,
				'range'   => [
					'ms' => [
						'min'  => 100,
						'max'  => 10000,
						'step' => 100,
					],
				],
				'default' => [
					'unit' => 'ms',
					'size' => 1200,
				],
			]
		);

		$this->add_control(
			'direction',
			[
				'label'   => esc_html__( 'Direction', 'rubenz' ),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'ltr',
				'options' => [
					'ltr' => [
						'title' => esc_html__( 'Left to Right', 'rubenz' ),
						'icon'  => 'fa fa-angle-double-right',
					],
					'rtl' => [
						'title' => esc_html__( 'Right to Left', 'rubenz' ),
						'icon'  => 'fa fa-angle-double-left',
					],
				],
				'toggle'  => false,
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		$this->add_render_attribute(
			'swiper', [
				'class'                       => [ 'swiper-container', 'slider', 'slider_draggable', 'slider-images', 'js-slider-images', 'text-center' ],
				'data-speed'                  => $settings['speed']['size'],
				'dir'                         => $settings['direction'],
				'data-slides-per-view'        => $settings['slides_per_view']['size'],
				'data-slides-per-view-tablet' => $settings['slides_per_view_tablet']['size'],
				'data-slides-per-view-mobile' => $settings['slides_per_view_mobile']['size'],
				'data-space-between'          => $settings['space_between']['size'],
				'data-space-between-tablet'   => $settings['space_between_tablet']['size'],
				'data-space-between-mobile'   => $settings['space_between_mobile']['size'],
				'data-centered-slides'        => $settings['centered_slides'],
				'data-centered-slides-tablet' => $settings['centered_slides_tablet'],
				'data-centered-slides-mobile' => $settings['centered_slides_mobile'],
			]
		);

		if ( $settings['enable_autoplay'] ) {
			$this->add_render_attribute(
				'swiper', [
					'data-autoplay-enabled' => 'true',
					'data-autoplay-delay'   => $settings['autoplay_delay']['size'],
				]
			);
		}

		if ( $settings['vertical_centered_slides'] ) {

			$this->add_render_attribute(
				'swiper', [
					'class' => 'slider_vertical-centered',
				]
			);

		}

		?>

			<div <?php echo $this->get_render_attribute_string( 'swiper' ); ?>>
				<div class="swiper-wrapper">
					<?php if ( ! empty( $settings['images_gallery'] ) ) : ?>
						<?php foreach ( $settings['images_gallery'] as $image ) : ?>
							<div class="swiper-slide slider__slide">
								<?php $src = wp_get_attachment_image_src( $image['id'], 'full' ); ?>
								<?php $title = get_the_title( $image['id'] ); ?>
								<?php if ( $settings['enable_captions'] && ! empty( $title ) && $settings['captions_position'] == 'slider__caption_top' ) : ?>
									<div class="slider__caption <?php echo $settings['captions_position']; ?>"><?php echo $title; ?></div>
								<?php endif; ?>
								<img class="swiper-lazy" data-src="<?php echo $src[0]; ?>" src="#" width="<?php echo $src[1]; ?>"  height="<?php echo $src[2]; ?>" alt="">
								<?php if ( $settings['enable_captions'] && ! empty( $title ) && $settings['captions_position'] == 'slider__caption_bottom' ) : ?>
									<div class="slider__caption <?php echo $settings['captions_position']; ?>"><?php echo $title; ?></div>
								<?php endif; ?>
							</div>
						<?php endforeach; ?>
					<?php endif; ?>
				</div>
				<?php if ( $settings['enable_progress'] ) : ?>
					<div class="slider__progress">
						<div class="swiper-container slider__counter slider__counter_current js-slider-images-counter-current">
							<div class="swiper-wrapper"></div>
						</div>
						<div class="slider__progressbar js-slider-images-progress">
							<div class="slider__progressbar-fill"></div>
						</div>
						<div class="slider__counter slider__counter_total js-slider-images-counter-total">00</div>
					</div>
					<!-- - slider progress -->
				<?php endif; ?>
			</div>

		<?php
	}

}
