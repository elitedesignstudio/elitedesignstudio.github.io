<?php

/**
 * Get the option for the current page/post
 *
 * @param string $option
 * @param int    $post_id
 * @return string
 */
function arts_elementor_get_document_option( $option, $post_id = null ) {

	if ( $post_id == null ) {
		$post_id = get_the_ID();
	}

	if ( ! empty( $option ) ) {

		// Get the page settings manager
		$page_settings_manager = \Elementor\Core\Settings\Manager::get_settings_managers( 'page' );

		// Get the settings model for current post
		$page_settings_model = $page_settings_manager->get_model( $post_id );

		// Retrieve the settings we added before
		return $page_settings_model->get_settings( $option );

	}

	return false;

}
