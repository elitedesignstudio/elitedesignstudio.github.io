<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_action( 'init', 'arts_register_post_types' );
function arts_register_post_types() {

	$priority = 5;

	/**
	 * Portfolio
	 */
	$labels  = array(
		'name'                  => _x( 'Portfolio Items', 'Post Type General Name', 'rubenz' ),
		'singular_name'         => _x( 'Portfolio Item', 'Post Type Singular Name', 'rubenz' ),
		'menu_name'             => _x( 'Portfolio Items', 'Admin Menu text', 'rubenz' ),
		'name_admin_bar'        => _x( 'Portfolio Item', 'Add New on Toolbar', 'rubenz' ),
		'archives'              => esc_html__( 'Portfolio Item Archives', 'rubenz' ),
		'attributes'            => esc_html__( 'Portfolio Item Attributes', 'rubenz' ),
		'parent_item_colon'     => esc_html__( 'Parent Portfolio Item:', 'rubenz' ),
		'all_items'             => esc_html__( 'All Portfolio Items', 'rubenz' ),
		'add_new_item'          => esc_html__( 'Add New Portfolio Item', 'rubenz' ),
		'add_new'               => esc_html__( 'Add New', 'rubenz' ),
		'new_item'              => esc_html__( 'New Portfolio Item', 'rubenz' ),
		'edit_item'             => esc_html__( 'Edit Portfolio Item', 'rubenz' ),
		'update_item'           => esc_html__( 'Update Portfolio Item', 'rubenz' ),
		'view_item'             => esc_html__( 'View Portfolio Item', 'rubenz' ),
		'view_items'            => esc_html__( 'View Portfolio Items', 'rubenz' ),
		'search_items'          => esc_html__( 'Search Portfolio Item', 'rubenz' ),
		'not_found'             => esc_html__( 'Not found', 'rubenz' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'rubenz' ),
		'featured_image'        => esc_html__( 'Featured Image', 'rubenz' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'rubenz' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'rubenz' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'rubenz' ),
		'insert_into_item'      => esc_html__( 'Insert into Portfolio Item', 'rubenz' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this Portfolio Item', 'rubenz' ),
		'items_list'            => esc_html__( 'Portfolio Items list', 'rubenz' ),
		'items_list_navigation' => esc_html__( 'Portfolio Items list navigation', 'rubenz' ),
		'filter_items_list'     => esc_html__( 'Filter Portfolio Items list', 'rubenz' ),
	);
	$rewrite = array(
		'slug'       => 'portfolio',
		'with_front' => true,
		'pages'      => true,
		'feeds'      => true,
	);
	$args    = array(
		'label'               => esc_html__( 'Portfolio Item', 'rubenz' ),
		'description'         => esc_html__( '', 'rubenz' ),
		'labels'              => $labels,
		'menu_icon'           => 'dashicons-art',
		'supports'            => array( 'title', 'thumbnail', 'revisions' ),
		'taxonomies'          => array( 'arts_portfolio_category' ),
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'menu_position'       => $priority++,
		'show_in_admin_bar'   => true,
		'show_in_nav_menus'   => true,
		'can_export'          => true,
		'has_archive'         => false,
		'hierarchical'        => false,
		'exclude_from_search' => false,
		'show_in_rest'        => true,
		'publicly_queryable'  => true,
		'capability_type'     => 'post',
		'rewrite'             => $rewrite,
	);
	register_post_type( 'arts_portfolio_item', $args );

}

